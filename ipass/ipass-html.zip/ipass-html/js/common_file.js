// JavaScript Document

//Date range picker
$('#reservation').daterangepicker()
//Date range picker with time picker
$('#reservationtime').daterangepicker({ timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A' })
//Date range as a button
$('#daterange-btn').daterangepicker(
  {
	ranges   : {
	  'Today'       : [moment(), moment()],
	  'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
	  'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
	  'Last 30 Days': [moment().subtract(29, 'days'), moment()],
	  'This Month'  : [moment().startOf('month'), moment().endOf('month')],
	  'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
	},
	startDate: moment().subtract(29, 'days'),
	endDate  : moment()
  },
  function (start, end) {
	$('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
  }
)

//Date picker
    $('#datepicker').datepicker({
      autoclose: true
    })


//Responsive Tabs
$( 'ul.nav.nav-tabs  a' ).click( function ( e ) {
	e.preventDefault();
	$( this ).tab( 'show' );
  } );

  ( function( $ ) {
	  // Test for making sure event are maintained
	  $( '.js-alert-test' ).click( function () {
		alert( 'Button Clicked: Event was maintained' );
	  } );
	  fakewaffle.responsiveTabs( [ 'xs', 'sm' ] );
  } )( jQuery );
  
  


